﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using URLModule;
using URLModule.Controllers;

namespace URLModule.Tests.Controllers
{
    [TestClass]
    public class ValuesControllerTest
    {
        [TestMethod]
        public void Get()
        {
            // Arrange
            ValuesController controller = new ValuesController();

            // Act
            List<UserData> result = controller.Get("Vikas");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Count());
            Assert.AreEqual("Vikas", result.ElementAt(0).userToken);
        }

        [TestMethod]
        public void InsertCorrectData()
        {
            // Arrange
            ValuesController controller = new ValuesController();

            // Assert
            Assert.AreEqual(true, controller.Post("HI", "www.gmail.com"));
            Assert.AreEqual(true, controller.Post("Bye", "www.google.com"));
        }

        [TestMethod]
        public void InsertDuplicateData()
        {
            // Arrange
            ValuesController controller = new ValuesController();

            // Assert
            Assert.AreEqual(false, controller.Post("Vikas", "www.volvo.com"));
        }

        [TestMethod]
        public void InsertIncorrectData()
        {
            // Arrange
            ValuesController controller = new ValuesController();

            // Assert
            Assert.AreEqual(false, controller.Post("", "www.google.com"));
        }
        [TestMethod]
        public void DeleteExistingData()
        {
            // Arrange
            ValuesController controller = new ValuesController();

            // Assert
            Assert.AreEqual(true, controller.Delete("Vikas", "www.gmail.com"));
        }

        [TestMethod]
        public void DeletNonExistentData()
        {
            // Arrange
            ValuesController controller = new ValuesController();

            // Assert
            Assert.AreEqual(false, controller.Delete("user123", "www.gmail.com"));
        }
    }
}
