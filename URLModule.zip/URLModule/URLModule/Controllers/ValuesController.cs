﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web;
using System.Web.Http;
using System.Xml.Linq;

namespace URLModule.Controllers
{
    public class ValuesController : ApiController
    {
        string path = Environment.CurrentDirectory;
        XDocument xDoc = null;
        // GET api/values
        public List<UserData> Get(string userToken)
        {
            string fileFullPath = path + "UrlDetails.xml";
            List<UserData> userData = new List<UserData>();
            if (File.Exists(fileFullPath))
            {
                xDoc = XDocument.Load(fileFullPath);
                if (xDoc != null)
                {
                    userData = (from data in xDoc.Root.Elements("UserData")
                                where data.Element("UserToken").Value==userToken
                                select new UserData
                                {
                                    userToken = data.Element("UserToken").Value,
                                    url = data.Element("Url").Value
                                }).ToList();
                }

            }
            return userData;
        }

        // POST api/values
        public bool Post([FromBody]string userToken, [FromBody]string url)
        {
            bool result = false;
            string fileFullPath = path + "UrlDetails.xml";
            try
            {
                if (!(string.IsNullOrEmpty(userToken) && string.IsNullOrEmpty(url)))
                {
                    if (!File.Exists(fileFullPath))
                    {
                        xDoc = new XDocument(new XElement("UrlDetails",
                           new XElement("UserData",
                               new XElement("UserToken", userToken),
                               new XElement("Url", url),
                               new XElement("Domain", ""))));
                    }
                    else
                    {
                        xDoc = XDocument.Load(fileFullPath);
                        if (xDoc != null)
                        {
                            var userData = from data in xDoc.Root.Elements("UserData")
                                           where data.Element("UserToken").Value == userToken
                                                && data.Element("Url").Value == url
                                           select data;
                            if (userData.Count() == 0)
                            {
                                result = true;
                                XElement xElement = new XElement("UserData",
                                                        new XElement("UserToken", userToken),
                                                        new XElement("Url", url),
                                                        new XElement("Domain", ""));
                                xDoc.Root.Add(xElement);
                            }
                        }
                    }
                    if (xDoc != null)
                    {
                        xDoc.Save(fileFullPath);

                    }
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                xDoc = null;
            }

            return result;
        }
        // DELETE api/values/5
        public bool Delete(string userToken, string url)
        {
            bool result = false;
            string fileFullPath = path + "UrlDetails.xml";
            try
            {
                if (File.Exists(fileFullPath))
                {
                    xDoc = XDocument.Load(fileFullPath);
                    if (xDoc != null)
                    {
                        var dataDeletion = (from data in xDoc.Root.Elements("UserData")
                                            where data.Element("UserToken").Value == userToken &&
                                                  data.Element("Url").Value==url
                                            select data).ToList();
                        if (dataDeletion.Count > 0)
                        {
                            dataDeletion.ForEach(i => i.Remove());
                            xDoc.Save(fileFullPath);
                            result = true;
                        }
                    }

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                xDoc = null;
            }
            return result;
        }
    }

    public class UserData
    {
        public string userToken { get; set; }
        public string url { get; set; }
        public string domain { get; set; }
    }
}
